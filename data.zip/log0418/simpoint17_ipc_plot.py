import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
matplotlib.rcParams['font.sans-serif'] = ['Arial Unicode MS', 'SimHei', 'DejaVu Sans']

# 读取csv
csv_path = '/Users/qx/Documents/毕业设计/上板/log0418/simpoint17_events.csv'
df = pd.read_csv(csv_path)

# 需要对比的配置
configs = [
    'default',
    'phast_4his_3p_128_128_128_2p19',
    'phast_4his_3p_128_128_128_2p20',
    'phast_6his_2p19',
    'nonspeculative',
]

# 计算IPC
for config in configs:
    cycles_col = f'{config}_cycles'
    inst_col = f'{config}_instructions'
    ipc_col = f'{config}_ipc'
    if cycles_col in df.columns and inst_col in df.columns:
        df[ipc_col] = df[inst_col] / df[cycles_col]

# 画图：以default为基准，画出各配置IPC提升百分比
benchmarks = df['benchmark']
default_ipc = df['default_ipc']
plt.figure(figsize=(16,8))
bar_width = 0.15
x = np.arange(len(benchmarks))
colors = ['#888', '#2ecc71', '#3498db', '#e67e22', '#9b59b6']
for i, config in enumerate(configs[1:]):
    ipc_col = f'{config}_ipc'
    if ipc_col in df.columns:
        ratio = (df[ipc_col] / default_ipc * 100) - 100
        plt.bar(x + i*bar_width, ratio, width=bar_width, label=config, color=colors[i+1])
# baseline
plt.axhline(0, color='black', linewidth=1.5)
plt.xticks(x + bar_width*1.5, benchmarks, rotation=45, ha='right')
plt.ylabel('IPC提升(%)，default为0%基线')
plt.title('simpoint17各配置相对default的IPC提升')
plt.legend()
plt.tight_layout()
plt.savefig('/Users/qx/Documents/毕业设计/上板/log0418/simpoint17_ipc_compare.png', dpi=300)
print('simpoint17对比图已保存')
# 保存带IPC的csv
out_csv = '/Users/qx/Documents/毕业设计/上板/log0418/simpoint17_events_with_ipc.csv'
df.to_csv(out_csv, index=False)
print('带IPC的csv已保存')
