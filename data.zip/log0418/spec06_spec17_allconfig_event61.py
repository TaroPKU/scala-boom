import pandas as pd
import matplotlib.pyplot as plt
import matplotlib
matplotlib.rcParams['font.sans-serif'] = ['Arial Unicode MS', 'SimHei', 'DejaVu Sans']
import numpy as np
import os

# 配置列表
configs = [
    'default',
    'phast_4his_3p_128_128_128_2p20',
    'phast_6his_2p19',
    'phast_6his_026_2p19',  # 替换为新组
    'nonspeculative',
]

# 读取所有配置的csv
dfs = {}
for config in configs:
    csv_path = f'/Users/qx/Documents/毕业设计/上板/log0418/spec06_spec17_{config}_ipc_event61.csv'
    if os.path.exists(csv_path):
        dfs[config] = pd.read_csv(csv_path)

# 以default为基准，合成标签
labels = dfs['default']['suite'] + ':' + dfs['default']['benchmark']
x = np.arange(len(labels))
bar_width = 0.15
plt.figure(figsize=(20,10))
colors = ['#888', '#2ecc71', '#3498db', '#e67e22', '#9b59b6']
legend_map = {
    'default': 'Default',
    'phast_4his_3p_128_128_128_2p20': '4 Bits History',
    'phast_6his_2p19': '6 Bits History',
    'phast_6his_026_2p19': '6 Bits Fold History',
    'nonspeculative': 'Nonspeculative',
}
plt.rc('axes', titlesize=22)
plt.rc('axes', labelsize=18)
plt.rc('xtick', labelsize=15)
plt.rc('ytick', labelsize=15)
plt.rc('legend', fontsize=16)
for i, config in enumerate(configs):
    if config in dfs:
        mini_exc = dfs[config]['event61_mini_exception'].fillna(0)
        mini_exc_per_kinst = mini_exc / 2e8 * 1000
        plt.bar(x + i*bar_width, mini_exc_per_kinst, width=bar_width, label=legend_map.get(config, config), color=colors[i])
plt.xticks(x + bar_width*2, labels, rotation=90, ha='right', fontsize=15)
plt.ylabel('MPKI', fontsize=18)
plt.legend(fontsize=16)
plt.tight_layout()
plt.savefig('/Users/qx/Documents/毕业设计/上板/log0418/spec06_spec17_allconfig_event61.png', dpi=300)
print('所有配置mini exception 柱状图已保存')
