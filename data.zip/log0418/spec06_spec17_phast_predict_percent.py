import pandas as pd
import matplotlib.pyplot as plt
import matplotlib
matplotlib.rcParams['font.sans-serif'] = ['Arial Unicode MS', 'SimHei', 'DejaVu Sans']
import numpy as np
import os

# 配置

# 配置与图例映射
phast_configs = [
    'phast_4his_3p_128_128_128_2p20',
    'phast_6his_2p19',
    'phast_6his_026_2p19',
]
legend_map = {
    'default': 'Default',
    'phast_4his_3p_128_128_128_2p20': '4 Bits History',
    'phast_6his_2p19': '6 Bits History',
    'phast_6his_026_2p19': '6 Bits Fold History',
    'nonspeculative': 'Nonspeculative',
}


# 读取event61数据
base = '/Users/qx/Documents/毕业设计/上板/log0418/'
default_df = pd.read_csv(base + 'spec06_spec17_default_ipc_event61.csv')
nonspec_df = pd.read_csv(base + 'spec06_spec17_nonspeculative_ipc_event61.csv')
phast_dfs = {cfg: pd.read_csv(base + f'spec06_spec17_{cfg}_ipc_event61.csv') for cfg in phast_configs}

# 合成标签
labels = default_df['suite'] + ':' + default_df['benchmark']
x = np.arange(len(labels))
bar_width = 0.7
fig, axes = plt.subplots(3, 1, figsize=(22, 18), sharex=True)
colors = ['#2ecc71', '#3498db', '#e67e22']

for i, cfg in enumerate(phast_configs):
    event61_default = default_df['event61_mini_exception'].fillna(0)
    event61_nonspec = nonspec_df['event61_mini_exception'].fillna(0)
    event61_phast = phast_dfs[cfg]['event61_mini_exception'].fillna(0)
    total = event61_default - event61_nonspec
    eliminated = event61_default - event61_phast
    percent = np.where((total == 0) | (eliminated == 0), 0, eliminated / total * 100)
    special_idx = []
    for idx in range(len(labels)):
        if total.iloc[idx] < 2000:
            special_idx.append(idx)
    valid_idx = [i for i in range(len(percent)) if i not in special_idx]
    if valid_idx:
        mean_val_for_special = np.mean(percent[valid_idx])
    for idx in special_idx:
        percent[idx] = mean_val_for_special
    percent = np.clip(percent, 0, 100)
    ax = axes[i]
    ax.bar(x, percent, width=bar_width, color=colors[i], alpha=0.85, label=legend_map.get(cfg, cfg))
    mean_val = np.mean(percent)
    ax.axhline(mean_val, color='red', linestyle='--', linewidth=2, label=f'平均: {mean_val:.2f}%')
    ax.set_ylim(0, 100)
    ax.set_ylabel('消除的访存相关占比（%）', fontsize=15)
   
    ax.legend(fontsize=15)
axes[-1].set_xticks(x)
axes[-1].set_xticklabels(labels, rotation=90, ha='right', fontsize=13)
plt.xlabel('Benchmark', fontsize=15)
plt.tight_layout()
plt.savefig(base + 'spec06_spec17_phast_predict_percent_matrix.png', dpi=300)
print('phast三组分图+均值虚线已保存')
