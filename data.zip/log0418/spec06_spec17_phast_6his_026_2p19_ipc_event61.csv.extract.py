import os
import json
import csv

# 路径配置
dir06 = '/Users/qx/Documents/毕业设计/上板/log0418/simpoint06/phast_6his_026_2p19'
dir17 = '/Users/qx/Documents/毕业设计/上板/log0418/simpoint17/phast_6his_026_2p19'
outfile = '/Users/qx/Documents/毕业设计/上板/log0418/spec06_spec17_phast_6his_026_2p19_ipc_event61.csv'

def extract_from_log(logfile):
    events = {}
    with open(logfile, 'r') as f:
        for line in f:
            try:
                obj = json.loads(line.strip())
                if obj.get('type', '').startswith('event '):
                    idx = obj['type'].split()[-1]
                    events[idx] = int(obj['value'])
            except Exception:
                continue
    return events

import re
def scan_folder(folder, suite):
    rows = []
    for fname in os.listdir(folder):
        if not fname.endswith('_no_loop_predictor.log'):
            continue
        benchmark = fname.replace('_no_loop_predictor.log', '')
        # spec17: 去掉前缀数字和_r后缀
        if suite == 'SPEC17':
            benchmark = re.sub(r'^\d+\.', '', benchmark)
            benchmark = re.sub(r'_r$', '', benchmark)
        events = extract_from_log(os.path.join(folder, fname))
        cycles = events.get('0', 0)
        instructions = events.get('1', 0)
        event61 = events.get('61', 0)
        ipc = instructions / cycles if cycles else 0
        rows.append({
            'suite': suite,
            'benchmark': benchmark,
            'cycles': cycles,
            'instructions': instructions,
            'ipc': ipc,
            'event61_mini_exception': event61
        })
    return rows

rows = scan_folder(dir06, 'SPEC06') + scan_folder(dir17, 'SPEC17')

# 按原csv顺序排序
bench_order = [
    'astar','bzip2','cactusADM','calculix','dealII','gobmk','h264ref','hmmer','leslie3d','libquantum','milc','povray','sjeng','xalancbmk',
    'perlbench','gcc','bwaves','mcf','cactuBSSN','namd','lbm','omnetpp','x264','blender','cam4','deepsjeng','leela','nab','exchange2','fotonik3d','xz'
]

# 只保留bench_order中的基准项并排序
rows = [row for row in rows if row['benchmark'] in bench_order]
def bench_key(row):
    if row['suite'] == 'SPEC06':
        return (0, bench_order.index(row['benchmark']))
    else:
        return (1, bench_order.index(row['benchmark']))
rows.sort(key=bench_key)

with open(outfile, 'w', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=['suite','benchmark','cycles','instructions','ipc','event61_mini_exception'])
    writer.writeheader()
    for row in rows:
        writer.writerow(row)

print(f'数据已重新提取并保存到: {outfile}')
