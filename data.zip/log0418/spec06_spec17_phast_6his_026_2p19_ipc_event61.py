import os
import json
import csv
import re
from pathlib import Path

# 新增配置名
group_name = 'phast_6his_026_2p19'
base_dir = '/Users/qx/Documents/毕业设计/上板/log0418'
folders = [
    os.path.join(base_dir, 'simpoint06', group_name),
    os.path.join(base_dir, 'simpoint17', group_name)
]

rows = []
for folder in folders:
    suite = 'SPEC06' if 'simpoint06' in folder else 'SPEC17'
    for file_path in Path(folder).rglob('*_no_loop_predictor.log'):
        filename = file_path.name
        match = re.match(r'(.+?)_no_loop_predictor\.log', filename)
        if not match:
            continue
        bench = match.group(1)
        cycles = None
        insts = None
        ipc = None
        event61 = None
        with open(file_path, 'r', encoding='utf-8') as f:
            for line in f:
                try:
                    data = json.loads(line.strip())
                    t = data.get('type', '')
                    if t == 'event  0':
                        cycles = data.get('value')
                    elif t == 'event  1':
                        insts = data.get('value')
                    elif t == 'event 61':
                        event61 = data.get('value')
                except Exception:
                    continue
        if cycles and insts:
            ipc = insts / cycles
        rows.append({
            'suite': suite,
            'benchmark': bench,
            'cycles': cycles,
            'instructions': insts,
            'ipc': ipc,
            'event61_mini_exception': event61
        })

out_csv = os.path.join(base_dir, f'spec06_spec17_{group_name}_ipc_event61.csv')
with open(out_csv, 'w', newline='', encoding='utf-8') as f:
    writer = csv.DictWriter(f, fieldnames=['suite','benchmark','cycles','instructions','ipc','event61_mini_exception'])
    writer.writeheader()
    for row in rows:
        writer.writerow(row)
print(f'已保存: {out_csv}')
