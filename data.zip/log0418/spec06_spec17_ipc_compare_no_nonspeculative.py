import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
matplotlib.rcParams['font.sans-serif'] = ['Arial Unicode MS', 'SimHei', 'DejaVu Sans']
import os

# 配置列表（去掉nonspeculative）
configs = [
    'default',
    'phast_4his_3p_128_128_128_2p20',
    'phast_6his_026_2p19',  # 替换为新组
    'phast_6his_2p19',
]


# 读取合并去重后的项目列表
spec06 = pd.read_csv('/Users/qx/Documents/毕业设计/上板/log0418/simpoint06_events_with_ipc.csv')
spec17 = pd.read_csv('/Users/qx/Documents/毕业设计/上板/log0418/simpoint17_events_with_ipc.csv')
spec17['benchmark'] = spec17['benchmark'].str.replace(r'_r$', '', regex=True)
spec17['benchmark'] = spec17['benchmark'].str.replace(r'^\d+\.', '', regex=True)
spec06['benchmark'] = spec06['benchmark'].str.replace(r'^\d+\.', '', regex=True)
spec06['suite'] = 'SPEC06'
spec17['suite'] = 'SPEC17'
spec06 = spec06[~spec06['benchmark'].isin(spec17['benchmark'])]
all_data = pd.concat([spec06, spec17], ignore_index=True)


# 统一读取所有配置，包括phast_6his_026_2p19
phast_6his_026_2p19 = pd.read_csv('/Users/qx/Documents/毕业设计/上板/log0418/spec06_spec17_phast_6his_026_2p19_ipc_event61.csv')
phast_6his_026_2p19['benchmark'] = phast_6his_026_2p19['benchmark'].astype(str)
phast_6his_026_2p19['suite'] = phast_6his_026_2p19['suite'].astype(str)

benchmarks = all_data['suite'] + ':' + all_data['benchmark']
default_ipc = all_data['default_ipc']
plt.figure(figsize=(20,10))
bar_width = 0.35
x = np.arange(len(benchmarks))

legend_map = {
    'phast_4his_3p_128_128_128_2p20': '4 Bits History',
    'phast_6his_026_2p19': '6 Bits History',
    'phast_6his_2p19': '6 Bits Fold History',
}
color_map = {
    'phast_4his_3p_128_128_128_2p20': '#2ecc71',
    'phast_6his_026_2p19': '#3498db',
    'phast_6his_2p19': '#e67e22',
}
for config in configs[1:]:
    plt.figure(figsize=(20,10))
    plt.rc('axes', titlesize=22)
    plt.rc('axes', labelsize=18)
    plt.rc('xtick', labelsize=15)
    plt.rc('ytick', labelsize=15)
    plt.rc('legend', fontsize=16)
    if config == 'phast_6his_026_2p19':
        # 直接按顺序取ipc列
        ipc_vals = phast_6his_026_2p19['ipc'].values
        ratio = (ipc_vals / default_ipc * 100) - 100
        plt.bar(x, ratio, width=bar_width, label=legend_map[config], color=color_map[config])
        valid = (ipc_vals > 0) & (default_ipc > 0)
        log_ratios = np.log(ipc_vals[valid] / default_ipc[valid])
        geo_mean = np.exp(log_ratios.mean())
        plt.axhline((geo_mean-1)*100, color=color_map[config], linestyle='--', linewidth=2, label=f'几何均值: {(geo_mean-1)*100:+.4f}%')
    else:
        ipc_col = f'{config}_ipc'
        if ipc_col in all_data.columns:
            ratio = (all_data[ipc_col] / default_ipc * 100) - 100
            plt.bar(x, ratio, width=bar_width, label=legend_map[config], color=color_map[config])
            valid = (all_data[ipc_col] > 0) & (default_ipc > 0)
            log_ratios = np.log(all_data.loc[valid, ipc_col] / default_ipc[valid])
            geo_mean = np.exp(log_ratios.mean())
            plt.axhline((geo_mean-1)*100, color=color_map[config], linestyle='--', linewidth=2, label=f'几何均值: {(geo_mean-1)*100:+.4f}%')
    plt.axhline(0, color='black', linewidth=1.5)
    plt.xticks(x, benchmarks, rotation=90, ha='right', fontsize=15)
    plt.ylabel('IPC提升(%)', fontsize=18)
    plt.title(f'SPEC06+SPEC17（去除nonspeculative）{legend_map[config]}相对default的IPC提升', fontsize=22)
    plt.legend(fontsize=16)
    plt.tight_layout()
    out_path = f'/Users/qx/Documents/毕业设计/上板/log0418/spec06_spec17_ipc_compare_no_nonspeculative_{config}.png'
    plt.savefig(out_path, dpi=300)
    print(f'{legend_map[config]}的IPC对比图已保存: {out_path}')
