import pandas as pd
import matplotlib.pyplot as plt
import matplotlib
matplotlib.rcParams['font.sans-serif'] = ['Arial Unicode MS', 'SimHei', 'DejaVu Sans']
import numpy as np

# 读取csv
csv_path = '/Users/qx/Documents/毕业设计/上板/log0418/spec06_spec17_default_ipc_event61.csv'
df = pd.read_csv(csv_path)

# 合成标签
labels = df['suite'] + ':' + df['benchmark']
mini_exc = df['event61_mini_exception'].fillna(0)

plt.figure(figsize=(18,8))
x = np.arange(len(labels))
plt.bar(x, mini_exc, color='#3498db', alpha=0.8, edgecolor='black')
plt.xticks(x, labels, rotation=90, ha='right', fontsize=9)
plt.ylabel('mini exception 次数 (event 61)')
plt.title('SPEC06+SPEC17 default配置 mini exception 统计')
plt.tight_layout()
plt.savefig('/Users/qx/Documents/毕业设计/上板/log0418/spec06_spec17_default_event61.png', dpi=300)
print('mini exception 柱状图已保存')
