import os
import json
import csv
import re
from pathlib import Path

def extract_events_from_logs(root_dir):
    """
    提取所有*predictor.log文件的event 0（cycles）和event 1（instructions）
    返回：{配置名: {基准名: (cycles, instructions)}}
    """
    # 配置名为root_dir下的所有子目录
    configs = [d for d in Path(root_dir).iterdir() if d.is_dir()]
    all_data = {}
    for config in configs:
        config_name = config.name
        predictor_files = list(config.rglob('*predictor.log'))
        config_data = {}
        for file_path in predictor_files:
            filename = file_path.name
            match = re.match(r'(.+?)_no_loop_predictor\.log', filename)
            if not match:
                continue
            bench = match.group(1)
            cycles = None
            insts = None
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    for line in f:
                        line = line.strip()
                        if not line:
                            continue
                        try:
                            data = json.loads(line)
                            event_type = data.get('type', '')
                            if event_type == 'event  0':
                                cycles = data.get('value')
                            elif event_type == 'event  1':
                                insts = data.get('value')
                        except json.JSONDecodeError:
                            continue
                if cycles is not None and insts is not None:
                    config_data[bench] = (cycles, insts)
            except Exception as e:
                print(f"Error reading {file_path}: {e}")
        all_data[config_name] = config_data
    return all_data

def save_events_csv(all_data, output_csv):
    """
    保存为csv，行标为基准名，列为每个配置的cycles和instructions
    """
    # 收集所有基准名
    all_benches = set()
    for config_data in all_data.values():
        all_benches.update(config_data.keys())
    all_benches = sorted(all_benches)
    # 列名
    columns = []
    for config in all_data.keys():
        columns.append(f"{config}_cycles")
        columns.append(f"{config}_instructions")
    with open(output_csv, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(['benchmark'] + columns)
        for bench in all_benches:
            row = [bench]
            for config in all_data.keys():
                cycles, insts = all_data[config].get(bench, (None, None))
                row.extend([cycles, insts])
            writer.writerow(row)
    print(f"Saved: {output_csv}")

if __name__ == '__main__':
    base_dir = '/Users/qx/Documents/毕业设计/上板/log0418'
    for sub in ['simpoint06', 'simpoint17']:
        all_data = extract_events_from_logs(os.path.join(base_dir, sub))
        save_events_csv(all_data, os.path.join(base_dir, f'{sub}_events.csv'))
