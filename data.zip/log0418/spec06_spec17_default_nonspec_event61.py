import pandas as pd
import matplotlib.pyplot as plt
import matplotlib
# 恢复默认字体
matplotlib.rcParams['font.sans-serif'] = ['DejaVu Sans', 'Arial', 'sans-serif']
import numpy as np
import os

# 只保留default和nonspeculative
configs = ['default', 'nonspeculative']
colors = ['#3498db', '#FF4500']

# 读取csv
dfs = {}
for config in configs:
    csv_path = f'/Users/qx/Documents/毕业设计/上板/log0418/spec06_spec17_{config}_ipc_event61.csv'
    if os.path.exists(csv_path):
        dfs[config] = pd.read_csv(csv_path)

labels = dfs['default']['suite'] + ':' + dfs['default']['benchmark']
x = np.arange(len(labels))
bar_width = 0.7  # 加宽柱状图
plt.figure(figsize=(20,10))

# 计算每千条指令Mini Exception数量
mini_exc_default = dfs['default']['event61_mini_exception'].fillna(0) / 2e8 * 1000
mini_exc_nonspec = dfs['nonspeculative']['event61_mini_exception'].fillna(0) / 2e8 * 1000

# 重叠柱状图
plt.bar(x, mini_exc_default, width=bar_width, label='Speculative', color=colors[0], alpha=0.7)
plt.bar(x, mini_exc_nonspec, width=bar_width, label='Non-speculative', color=colors[1], alpha=0.7)

# 在nonspeculative柱上标注百分比
percent = np.where(mini_exc_default > 0, mini_exc_nonspec / mini_exc_default * 100, 0)
for i, (y, p) in enumerate(zip(mini_exc_nonspec, percent)):
    plt.text(x[i], y + 0.01, f'{p:.1f}%', ha='center', va='bottom', fontsize=14, color=colors[1])

plt.xticks(x, labels, rotation=90, ha='right', fontsize=14)
plt.xlim(-0.5, len(labels)-0.5)  # 缩短间距
plt.ylabel('Mini Exception per 1K Instructions', fontsize=18)
plt.title('SPEC06+SPEC17 Speculative/Non-speculative Mini Exception per 1K Instructions', fontsize=20)
plt.legend(fontsize=16)
plt.tight_layout()
plt.savefig('/Users/qx/Documents/毕业设计/上板/log0418/spec06_spec17_default_nonspec_event61.png', dpi=300)
print('default与nonspeculative重叠柱状图已保存')
