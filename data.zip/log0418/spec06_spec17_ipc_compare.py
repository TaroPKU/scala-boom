import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
matplotlib.rcParams['font.sans-serif'] = ['Arial Unicode MS', 'SimHei', 'DejaVu Sans']

# 读取两个csv
spec06 = pd.read_csv('/Users/qx/Documents/毕业设计/上板/log0418/simpoint06_events_with_ipc.csv')
spec17 = pd.read_csv('/Users/qx/Documents/毕业设计/上板/log0418/simpoint17_events_with_ipc.csv')

# 合并数据
spec06['suite'] = 'spec06'
spec17['suite'] = 'spec17'
all_data = pd.concat([spec06, spec17], ignore_index=True)

# 选择要对比的配置
configs = [
    'default',
    'phast_4his_3p_128_128_128_2p19',
    'phast_4his_3p_128_128_128_2p20',
    'phast_6his_2p19',
    'nonspeculative',
]

# 画图
plt.figure(figsize=(20,10))
bar_width = 0.15
benchmarks = all_data['suite'] + ':' + all_data['benchmark']
x = np.arange(len(benchmarks))
default_ipc = all_data['default_ipc']
colors = ['#888', '#2ecc71', '#3498db', '#e67e22', '#9b59b6']
for i, config in enumerate(configs[1:]):
    ipc_col = f'{config}_ipc'
    if ipc_col in all_data.columns:
        ratio = (all_data[ipc_col] / default_ipc * 100) - 100
        plt.bar(x + i*bar_width, ratio, width=bar_width, label=config, color=colors[i+1])
        # 计算几何均值
        valid = (all_data[ipc_col] > 0) & (default_ipc > 0)
        log_ratios = np.log(all_data.loc[valid, ipc_col] / default_ipc[valid])
        geo_mean = np.exp(log_ratios.mean())
        plt.axhline((geo_mean-1)*100, color=colors[i+1], linestyle='--', linewidth=2, label=f'{config} 几何均值: {(geo_mean-1)*100:+.4f}%')
plt.axhline(0, color='black', linewidth=1.5)
plt.xticks(x + bar_width*1.5, benchmarks, rotation=90, ha='right', fontsize=9)
plt.ylabel('IPC提升(%)，default为0%基线')
plt.title('spec06+spec17 各配置相对default的IPC提升')
plt.legend()
plt.tight_layout()
plt.savefig('/Users/qx/Documents/毕业设计/上板/log0418/spec06_spec17_ipc_compare.png', dpi=300)
print('spec06+spec17合并对比图已保存')
