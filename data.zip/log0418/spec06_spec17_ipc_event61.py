import pandas as pd
import json
import re
from pathlib import Path

# 配置列表
configs = [
    'default',
    'phast_4his_3p_128_128_128_2p19',
    'phast_4his_3p_128_128_128_2p20',
    'phast_6his_2p19',
    'nonspeculative',
]

# 读取合并去重后的项目列表
spec06 = pd.read_csv('/Users/qx/Documents/毕业设计/上板/log0418/simpoint06_events_with_ipc.csv')
spec17 = pd.read_csv('/Users/qx/Documents/毕业设计/上板/log0418/simpoint17_events_with_ipc.csv')
# 处理benchmark名，去掉_r和前缀序号
spec17['benchmark'] = spec17['benchmark'].str.replace(r'_r$', '', regex=True)
spec17['benchmark'] = spec17['benchmark'].str.replace(r'^\d+\.', '', regex=True)
spec06['benchmark'] = spec06['benchmark'].str.replace(r'^\d+\.', '', regex=True)
spec06['suite'] = 'SPEC06'
spec17['suite'] = 'SPEC17'
spec06 = spec06[~spec06['benchmark'].isin(spec17['benchmark'])]
all_data = pd.concat([spec06, spec17], ignore_index=True)

# 遍历每个配置，生成一份csv
for config in configs:
    rows = []
    for idx, row in all_data.iterrows():
        suite = row['suite']
        bench = row['benchmark']
        # log0418下递归查找对应配置的predictor.log
        log_root = f'/Users/qx/Documents/毕业设计/上板/log0418'
        # 组名与配置名对应
        pat = f'{config}/*{bench}*_no_loop_predictor.log'
        matches = list(Path(log_root).rglob(pat))
        if not matches and suite == 'SPEC17':
            pat2 = f'{config}/*{bench}_r_no_loop_predictor.log'
            matches = list(Path(log_root).rglob(pat2))
        if not matches:
            print(f'未找到 {suite}:{bench} {config} 的log文件')
            continue
        log_path = matches[0]
        cycles = None
        insts = None
        ipc = None
        event61 = None
        # 读取event 0/1/61
        with open(log_path, 'r', encoding='utf-8') as f:
            for line in f:
                try:
                    data = json.loads(line.strip())
                    t = data.get('type', '')
                    if t == f'event  0':
                        cycles = data.get('value')
                    elif t == f'event  1':
                        insts = data.get('value')
                    elif t == 'event 61':
                        event61 = data.get('value')
                except Exception:
                    continue
        # 优先用csv中的cycles/instructions/ipc
        cycles_col = f'{config}_cycles'
        insts_col = f'{config}_instructions'
        ipc_col = f'{config}_ipc'
        cycles_csv = row[cycles_col] if cycles_col in row else None
        insts_csv = row[insts_col] if insts_col in row else None
        ipc_csv = row[ipc_col] if ipc_col in row else None
        rows.append({
            'suite': suite,
            'benchmark': bench,
            'cycles': cycles_csv if pd.notnull(cycles_csv) else cycles,
            'instructions': insts_csv if pd.notnull(insts_csv) else insts,
            'ipc': ipc_csv if pd.notnull(ipc_csv) else (insts / cycles if cycles and insts else None),
            'event61_mini_exception': event61
        })
    out_csv = f'/Users/qx/Documents/毕业设计/上板/log0418/spec06_spec17_{config}_ipc_event61.csv'
    pd.DataFrame(rows).to_csv(out_csv, index=False)
    print(f'已保存: {out_csv}')
