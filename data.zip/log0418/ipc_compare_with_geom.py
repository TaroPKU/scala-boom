import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
matplotlib.rcParams['font.sans-serif'] = ['Arial Unicode MS', 'SimHei', 'DejaVu Sans']

def plot_ipc(csv_path, out_png, out_csv, title):
    df = pd.read_csv(csv_path)
    configs = [
        'default',
        'phast_4his_3p_128_128_128_2p19',
        'phast_4his_3p_128_128_128_2p20',
        'phast_6his_2p19',
        'nonspeculative',
    ]
    for config in configs:
        cycles_col = f'{config}_cycles'
        inst_col = f'{config}_instructions'
        ipc_col = f'{config}_ipc'
        if cycles_col in df.columns and inst_col in df.columns:
            df[ipc_col] = df[inst_col] / df[cycles_col]
    benchmarks = df['benchmark']
    default_ipc = df['default_ipc']
    plt.figure(figsize=(16,8))
    bar_width = 0.15
    x = np.arange(len(benchmarks))
    colors = ['#888', '#2ecc71', '#3498db', '#e67e22', '#9b59b6']
    geo_means = []
    for i, config in enumerate(configs[1:]):
        ipc_col = f'{config}_ipc'
        if ipc_col in df.columns:
            ratio = (df[ipc_col] / default_ipc * 100) - 100
            plt.bar(x + i*bar_width, ratio, width=bar_width, label=config, color=colors[i+1])
            # 计算几何均值
            valid = (df[ipc_col] > 0) & (default_ipc > 0)
            log_ratios = np.log(df.loc[valid, ipc_col] / default_ipc[valid])
            geo_mean = np.exp(log_ratios.mean())
            geo_means.append(geo_mean)
            # 虚线
            plt.axhline((geo_mean-1)*100, color=colors[i+1], linestyle='--', linewidth=2, label=f'{config} 几何均值: {(geo_mean-1)*100:+.4f}%')
    plt.axhline(0, color='black', linewidth=1.5)
    plt.xticks(x + bar_width*1.5, benchmarks, rotation=45, ha='right')
    plt.ylabel('IPC提升(%)，default为0%基线')
    plt.title(title)
    plt.legend()
    plt.tight_layout()
    plt.savefig(out_png, dpi=300)
    print(f'{title} 对比图已保存')
    df.to_csv(out_csv, index=False)
    print(f'带IPC的csv已保存: {out_csv}')

if __name__ == '__main__':
    plot_ipc(
        '/Users/qx/Documents/毕业设计/上板/log0418/simpoint06_events.csv',
        '/Users/qx/Documents/毕业设计/上板/log0418/simpoint06_ipc_compare.png',
        '/Users/qx/Documents/毕业设计/上板/log0418/simpoint06_events_with_ipc.csv',
        'simpoint06各配置相对default的IPC提升')
    plot_ipc(
        '/Users/qx/Documents/毕业设计/上板/log0418/simpoint17_events.csv',
        '/Users/qx/Documents/毕业设计/上板/log0418/simpoint17_ipc_compare.png',
        '/Users/qx/Documents/毕业设计/上板/log0418/simpoint17_events_with_ipc.csv',
        'simpoint17各配置相对default的IPC提升')
